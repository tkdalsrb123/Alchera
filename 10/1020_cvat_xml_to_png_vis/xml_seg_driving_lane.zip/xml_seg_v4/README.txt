// README.txt

python main.py <xml-dir> <output-dir>