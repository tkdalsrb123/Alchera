
# WARNING! (B, G, R) not (R, G, B)
SEGMENT_COLOR = (0, 0, 0)
'''
TEXT_DICT = {

}
'''
# ALPHA = 0.5

SEGMENT_COLOR_DICT = {
    'CarEmergency' : (114, 128, 250),
    'CarSchool bus' : (0, 215, 255),
    'BusEmergency' : (0, 140, 255),
    'BusSchool bus' : (0, 255, 255),
    'TruckEmergency' : (0, 69, 255),
    'CyclistnoRider' : (47, 255, 173),
    'MotorcyclenoRider' : (127, 255, 0),
    'RoadCounter lane' : (190, 190, 190),
}
SEGMENT_THICKNESS = 5

SEGMENT_WIDTH = 1

BBOX_COLOR = (0, 0, 255)
BBOX_THICKNESS = 5

POINT_RADIUS = 2
POINT_THICKNESS = 5
POINT_COLOR = (0, 0, 255)