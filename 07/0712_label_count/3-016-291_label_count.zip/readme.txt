2023-07-13

1. 요청사항
[3-016-291 label count 코드 요청]

2. 실행방법
python main.py [input 최상위 폴더] [output 폴더]

- output 폴더에 count.xlsx로 저장