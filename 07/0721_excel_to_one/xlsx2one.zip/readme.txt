2023-07-21

1. 요청사항
[다수의 excel에서 필요한 셀값만 1개의 exce 파일 출력]

2. 실행방법
python xlsx2one.py [input 최상위 폴더] [output 폴더]

- output 폴더에 xlsx2one.xlsx 로 저장
