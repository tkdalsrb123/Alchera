1204 상우진

1. 요청사항
[[TTA] 075-096 바운딩 박스 시각화 코드 요청]

2. 실행방법
python main.py [input_dir] [output_dir]